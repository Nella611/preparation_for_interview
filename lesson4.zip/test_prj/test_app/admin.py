from django.contrib import admin

from .models import GoodItem

admin.site.register(GoodItem)

# Register your models here.
